//
//  ViewController.m
//  MainSTSample
//
//  Created by Harpreet Singh on 09/09/13.
//  Copyright (c) 2013 apple. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.navigationItem.title = @"Demo";
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];
}


- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
   
    
    if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive)
    {
        // Configure the new event with information from the location
        CLLocationCoordinate2D coordinate = [newLocation coordinate];
        
        NSString *latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
        NSString *longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
        
        locationlbl.text = [NSString stringWithFormat:@"Lat:%@,Long:%@", latitude, longitude];
        
        NSLog(@"Latitude : %@", latitude);
        NSLog(@"Longitude : %@",longitude);
        
    }
    else
    {
        NSLog(@"App is backgrounded. New location is %@", newLocation);
        
        // Configure the new event with information from the location
        CLLocationCoordinate2D coordinate = [newLocation coordinate];
        
        NSString *latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
        NSString *longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
        
        locationlbl.text = [NSString stringWithFormat:@"bag Lat:%@,bag Long:%@", latitude, longitude];
        
        NSLog(@"backgrounded Latitude : %@", latitude);
        NSLog(@"backgrounded Longitude : %@",longitude);
        
    }
    
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    if(error.code == kCLErrorDenied)
    {
        [locationManager stopUpdatingLocation];
    }
    else if(error.code == kCLErrorLocationUnknown)
    {
        // retry
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error retrieving location"
                                                        message:[error description]
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
