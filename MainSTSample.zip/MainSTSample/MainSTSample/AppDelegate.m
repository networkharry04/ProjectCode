//
//  AppDelegate.m
//  MainSTSample
//
//  Created by Harpreet Singh on 09/09/13.
//  Copyright (c) 2013 apple. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"
#import "ResultViewController.h"
#import "AFNetworking.h"
#import "AFHTTPClient.h"

@implementation AppDelegate

@synthesize locationManager, locations, nav;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    //************ APNS ***********************
    // Let the device know we want to receive push notifications
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    //*****************************************
    
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://192.168.0.200:8888/"]];
    [httpClient setParameterEncoding:AFJSONParameterEncoding];
    NSDictionary *p=@{@"name": @"sumet"};
    
    // NSMutableURLRequest *request = [httpClient requestWithMethod:@"POST"
    //                     path:@"iphone/iphone_php/register.php"
    //                 parameters:p];
    
    NSMutableURLRequest *request = [httpClient requestWithMethod:@"POST"
                                                            path:@"iphone/iphone_php/register.php"
                                                      parameters:p];
 
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        // Print the response body in text
        NSLog(@"Response: %@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
    }];
    [operation start];
    
           
    //************** Location Manager *********************
    self.locations = [[NSMutableArray alloc] init];
    
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
    self.locationManager.delegate = self;
    self.locationManager.distanceFilter = kCLDistanceFilterNone;
    [self.locationManager startUpdatingLocation];
    
    //***********************************
    
    
    
    // Override point for customization after application launch.
    self.viewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];    
    nav = [[UINavigationController alloc] initWithRootViewController:self.viewController];   
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    
    return YES;
}

//*********** APNS Delegater Mehotds ***********
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString* deviceTokenString = [deviceToken description];
    
    deviceTokenString = [deviceTokenString stringByReplacingOccurrencesOfString:@"<" withString:@""];
    deviceTokenString = [deviceTokenString stringByReplacingOccurrencesOfString:@">" withString:@""];
    deviceTokenString = [deviceTokenString stringByReplacingOccurrencesOfString:@" " withString:@""];
	NSLog(@"Device Token : %@", deviceTokenString);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Device Token Registered Successfully" message:deviceTokenString
                                                   delegate:nil
                                          cancelButtonTitle:@"Ok"
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	//NSString* deviceToken = @"";

    NSLog(@"%@", error);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"token" message:@"fail"
                                                   delegate:nil
                                          cancelButtonTitle:@"Ok"
                                          otherButtonTitles:nil];
    [alert show];
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"User info %@", userInfo);

    NSMutableDictionary *dict  = [[NSMutableDictionary alloc] initWithDictionary:[userInfo objectForKey:@"aps"]];
    
    NSLog(@"First %@", dict);
    
    dict3  = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"alert"]];
    
    NSLog(@"second %@", dict3);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notify" message:[dict3 valueForKey:@"msg"]
                                                   delegate:self
                                          cancelButtonTitle:@"Ok"
                                          otherButtonTitles:nil];
    [alert show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        ResultViewController *rvc =[[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
        rvc.str = [NSString stringWithFormat:@"Store Name : %@ \n Description : %@ \n Message : %@ ", [dict3 valueForKey:@"store"],  [dict3 valueForKey:@"txt"],  [dict3 valueForKey:@"msg"]];
        [self.nav pushViewController:rvc animated:YES];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSDate *newLocationTimestamp = newLocation.timestamp;
    NSDate *oldLocationTimestamp = oldLocation.timestamp;
    
    int locationUpdateInterval = 15;
    
    if (!([newLocationTimestamp timeIntervalSinceDate:oldLocationTimestamp] < locationUpdateInterval))
    {
        [self updateToLocation:newLocation];
    }
    
}
- (void)updateToLocation:(CLLocation *)newLocation
{
    NSLog(@"update location!!");
    
    CLLocationCoordinate2D coordinate;
    NSString *latitude;
    NSString *longitude;
    
    if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive)
    {
        coordinate = [newLocation coordinate];
        
        latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
        
        
        NSLog(@"Latitude : %@", latitude);
        NSLog(@"Longitude : %@",longitude);
        
        
    }
    else
    {
        NSLog(@"App is backgrounded. New location is %@", newLocation);
        
        coordinate = [newLocation coordinate];
        
        latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
        
        NSLog(@"backgrounded Latitude : %@", latitude);
        NSLog(@"backgrounded Longitude : %@",longitude);
    }

    
    
    
    //[currentUser updatePositionWithLongitude:longitude andLatitude:latitude];
}

       
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [self.locationManager stopUpdatingLocation];
    
    
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
