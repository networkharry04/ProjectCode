//
//  ResultViewController.h
//  MainSTSample
//
//  Created by Harpreet Singh on 13/09/13.
//  Copyright (c) 2013 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultViewController : UIViewController
{
    IBOutlet UILabel *locationlbl;
    
}

@property (strong, nonatomic) NSString *str;

@end
