//
//  ViewController.h
//  MainSTSample
//
//  Created by Harpreet Singh on 09/09/13.
//  Copyright (c) 2013 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "AppDelegate.h"

@interface ViewController : UIViewController <CLLocationManagerDelegate>
{
    AppDelegate *appDel;
    
    CLLocationManager *locationManager;
    
    IBOutlet UILabel *locationlbl;
    
}

@end
